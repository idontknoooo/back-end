# Topic
Restaurant Service
# Use
- In 'restaurant' folder, run `docker-compose up`
- `mvn clean install`
- `java -jar target/*.jar`
- Use `*.json` files in restaurant folder to fill HTTP requests with POSTMAN